# Before publishing

- [ ] Review instructor-provided skeleton code and educational-use notices for redistribution permission.
- [ ] Distinguish your own changes from supplied scaffolding and sample Jack programs.
- [ ] Remove or replace hardcoded test paths in `hvm.py` when you want general CLI use.
- [ ] Run the Nand2Tetris tests locally with properly licensed course fixtures.
- [ ] Check the README for accuracy and add screenshots/results if available.

This cleanup removes caches, generated files, and test fixtures but does not certify that every remaining file is yours to publish.
